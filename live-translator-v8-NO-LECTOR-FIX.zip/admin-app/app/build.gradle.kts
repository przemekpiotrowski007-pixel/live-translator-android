plugins { id("com.android.application") }
android { namespace="pl.livetranslator.admin"; compileSdk=35
 defaultConfig { applicationId="pl.livetranslator.admin"; minSdk=29; targetSdk=35; versionCode=1; versionName="1.0" }
}
