# Live Translator PL v6 FAST
- Audio systemowe przez MediaProjection / AudioPlaybackCapture
- EN i DE -> PL
- szybkie tłumaczenie częściowe (~1.1 s debounce)
- stare odpowiedzi tłumacza są odrzucane, aby opóźnienie nie narastało
- Napisy PL i Lektor PL niezależnie
- automatyczny wybór najlepszego lokalnego polskiego głosu TTS dostępnego na telefonie
- ekran aktywacji licencji; w APK zapisane są wyłącznie SHA-256 kodów
- Vosk offline STT + ML Kit Translation
