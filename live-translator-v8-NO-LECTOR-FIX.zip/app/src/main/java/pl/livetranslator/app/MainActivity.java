package pl.livetranslator.app;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.widget.*;
import androidx.activity.result.*;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.zip.*;

public class MainActivity extends AppCompatActivity {
 Spinner lang; CheckBox subs; TextView status,pl,src,licenseStatus; EditText licenseCode;
 MediaProjectionManager mpm;
 final Handler h=new Handler(Looper.getMainLooper());

 final ActivityResultLauncher<String[]> perms=registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(),r->askProjection());
 final ActivityResultLauncher<Intent> projection=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),r->{
   if(r.getResultCode()!=Activity.RESULT_OK||r.getData()==null){status.setText("Anulowano wybór źródła.");return;}
   Intent s=new Intent(this,CaptureService.class);
   s.putExtra("code",r.getResultCode()); s.putExtra("data",r.getData());
   s.putExtra("lang",lang.getSelectedItemPosition()==0?"en":"de");
   s.putExtra("subs",subs.isChecked());
   ContextCompat.startForegroundService(this,s);
   status.setText("Uruchamiam przechwytywanie audio…");
 });

 @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
   lang=findViewById(R.id.langSpinner);subs=findViewById(R.id.subCheck);
   status=findViewById(R.id.status);pl=findViewById(R.id.plText);src=findViewById(R.id.srcText); licenseStatus=findViewById(R.id.licenseStatus); licenseCode=findViewById(R.id.licenseCode);
   ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Angielski (EN)","Niemiecki (DE)"});
   lang.setAdapter(a);mpm=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
   findViewById(R.id.licenseButton).setOnClickListener(v->activate());
   licenseStatus.setText(licensed()?"Licencja ONLINE: AKTYWNA ✓":"Licencja: nieaktywna");
   findViewById(R.id.modelButton).setOnClickListener(v->{if(licensed())downloadModel();else status.setText("Najpierw aktywuj licencję.");});
   findViewById(R.id.startButton).setOnClickListener(v->start());
   findViewById(R.id.stopButton).setOnClickListener(v->{stopService(new Intent(this,CaptureService.class));status.setText("Zatrzymano.");});
   h.post(ui);
 }
 String code(){return lang.getSelectedItemPosition()==0?"en":"de";}
 File modelDir(String c){return new File(getFilesDir(),"vosk-"+c);}
 boolean ready(String c){return new File(modelDir(c),"am").exists()||new File(modelDir(c),"conf").exists();}
 void downloadModel(){
   String c=code(); if(ready(c)){status.setText("Model "+c.toUpperCase()+" jest gotowy.");return;}
   status.setText("Pobieram model "+c.toUpperCase()+"…");
   new Thread(()->{
    String name=c.equals("en")?"vosk-model-small-en-us-0.15":"vosk-model-small-de-0.15";
    File zip=new File(getCacheDir(),name+".zip"), out=modelDir(c), tmp=new File(getFilesDir(),"tmp-"+c);
    try{
      if(tmp.exists())del(tmp);tmp.mkdirs();
      URL u=new URL("https://alphacephei.com/vosk/models/"+name+".zip");
      HttpURLConnection con=(HttpURLConnection)u.openConnection();con.setConnectTimeout(20000);con.setReadTimeout(30000);
      try(InputStream in=con.getInputStream();OutputStream os=new FileOutputStream(zip)){
        byte[]buf=new byte[65536];long n=0;int k;while((k=in.read(buf))>0){os.write(buf,0,k);n+=k;long mb=n/1048576;runOnUiThread(()->status.setText("Pobieranie "+c.toUpperCase()+": "+mb+" MB"));}}
      unzip(zip,tmp);
      File inner=new File(tmp,name); if(out.exists())del(out);
      if(inner.exists()) inner.renameTo(out); else tmp.renameTo(out);
      zip.delete(); if(tmp.exists()&&!tmp.equals(out))del(tmp);
      runOnUiThread(()->status.setText("Model "+c.toUpperCase()+" gotowy. Możesz nacisnąć START."));
    }catch(Exception e){runOnUiThread(()->status.setText("Błąd modelu: "+e.getMessage()));}
   }).start();
 }
 void unzip(File z,File d)throws Exception{try(ZipInputStream in=new ZipInputStream(new BufferedInputStream(new FileInputStream(z)))){
   ZipEntry e;byte[]b=new byte[65536];while((e=in.getNextEntry())!=null){File f=new File(d,e.getName());String base=d.getCanonicalPath()+File.separator;if(!f.getCanonicalPath().startsWith(base))throw new IOException("ZIP");
   if(e.isDirectory())f.mkdirs();else{f.getParentFile().mkdirs();try(OutputStream o=new BufferedOutputStream(new FileOutputStream(f))){int n;while((n=in.read(b))>0)o.write(b,0,n);}}}}}
 void del(File f){if(f.isDirectory()){File[]x=f.listFiles();if(x!=null)for(File q:x)del(q);}f.delete();}
 boolean licensed(){return getSharedPreferences("license",MODE_PRIVATE).getBoolean("ok",false);}
 void activate(){
   String key=licenseCode.getText().toString().trim().toUpperCase(Locale.ROOT);
   if(key.isEmpty()){licenseStatus.setText("Wpisz kod licencji");return;}
   licenseStatus.setText("Sprawdzam licencję...");
   new Thread(()->{
     try{
       String androidId=android.provider.Settings.Secure.getString(getContentResolver(),android.provider.Settings.Secure.ANDROID_ID);
       String raw=androidId+"|"+getPackageName();
       StringBuilder dh=new StringBuilder();for(byte q:java.security.MessageDigest.getInstance("SHA-256").digest(raw.getBytes("UTF-8")))dh.append(String.format("%02x",q));
       java.net.URL u=new java.net.URL("https://sqaloqswimqspajcczzs.supabase.co/functions/v1/license-check");
       java.net.HttpURLConnection c=(java.net.HttpURLConnection)u.openConnection();c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(8000);c.setReadTimeout(8000);
       c.setRequestProperty("Content-Type","application/json");
       c.setRequestProperty("apikey","sb_publishable_IkeRBslSIP9GC8loHxLfQA_MsIJyrdH");
       org.json.JSONObject j=new org.json.JSONObject();j.put("license_key",key);j.put("device_hash",dh.toString());j.put("device_name",android.os.Build.MANUFACTURER+" "+android.os.Build.MODEL);
       try(java.io.OutputStream os=c.getOutputStream()){os.write(j.toString().getBytes("UTF-8"));}
       int code=c.getResponseCode(); java.io.InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream();
       String body="";if(is!=null){java.util.Scanner sc=new java.util.Scanner(is,"UTF-8").useDelimiter("\\A");body=sc.hasNext()?sc.next():"";}
       boolean ok=code>=200&&code<300&&new org.json.JSONObject(body).optBoolean("ok",false);
       runOnUiThread(()->{if(ok){getSharedPreferences("license",MODE_PRIVATE).edit().putBoolean("ok",true).putString("key",key).apply();licenseStatus.setText("Licencja ONLINE: AKTYWNA ✓");licenseCode.setText("");status.setText("Aktywowano online. Przygotuj język.");}else{licenseStatus.setText("Licencja odrzucona / zablokowana");}});
     }catch(Exception e){runOnUiThread(()->licenseStatus.setText("Brak połączenia z serwerem licencji"));}
   }).start();
 }
 void start(){
   if(!licensed()){status.setText("Najpierw aktywuj licencję.");return;}
   if(!ready(code())){status.setText("Najpierw kliknij POBIERZ / PRZYGOTUJ JĘZYK.");return;}
   ArrayList<String>p=new ArrayList<>();
   if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.RECORD_AUDIO);
   if(Build.VERSION.SDK_INT>=33&&ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.POST_NOTIFICATIONS);
   if(!p.isEmpty())perms.launch(p.toArray(new String[0]));else askProjection();
 }
 void askProjection(){projection.launch(mpm.createScreenCaptureIntent());}
 final Runnable ui=new Runnable(){public void run(){var p=getSharedPreferences("live",MODE_PRIVATE);
   String st=p.getString("status","");if(!st.isEmpty())status.setText(st);
   String s=p.getString("src","");if(!s.isEmpty())src.setText("Oryginał: "+s);
   String t=p.getString("pl","");if(!t.isEmpty()&&subs.isChecked())pl.setText(t);
   h.postDelayed(this,400);}};
 @Override protected void onDestroy(){h.removeCallbacks(ui);super.onDestroy();}
}