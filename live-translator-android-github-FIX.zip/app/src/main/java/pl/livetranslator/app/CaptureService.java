package pl.livetranslator.app;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.speech.tts.TextToSpeech;
import androidx.core.app.NotificationCompat;
import com.google.mlkit.nl.translate.*;
import com.google.mlkit.common.model.DownloadConditions;
import org.vosk.*;
import org.json.JSONObject;
import java.io.File;
import java.util.Locale;

public class CaptureService extends Service {
 MediaProjection mp; AudioRecord record; Recognizer recognizer; Model model; Translator translator; TextToSpeech ttsEngine; Thread audioThread; volatile boolean running;
 String lang; boolean useTts; long lastSpeak=0; SharedPreferences p;
 @Override public void onCreate(){super.onCreate();p=getSharedPreferences("live",MODE_PRIVATE);
   NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel("live","Live Translator",NotificationManager.IMPORTANCE_LOW));
 }
 @Override public int onStartCommand(Intent i,int flags,int id){
   Notification n=new NotificationCompat.Builder(this,"live").setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("Live Translator PL").setContentText("Tłumaczenie audio systemowego").setOngoing(true).build();
   if(Build.VERSION.SDK_INT>=29)startForeground(7,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);else startForeground(7,n);
   try{
    int code=i.getIntExtra("code",Activity.RESULT_CANCELED);Intent data=Build.VERSION.SDK_INT>=33?i.getParcelableExtra("data",Intent.class):i.getParcelableExtra("data");
    lang=i.getStringExtra("lang");useTts=i.getBooleanExtra("tts",false);
    MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);mp=m.getMediaProjection(code,data);
    mp.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){stopSelf();}},new Handler(Looper.getMainLooper()));
    AudioPlaybackCaptureConfiguration cfg=new AudioPlaybackCaptureConfiguration.Builder(mp).addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_GAME).addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build();
    AudioFormat fmt=new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(16000).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build();
    int bs=Math.max(8192,AudioRecord.getMinBufferSize(16000,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)*2);
    record=new AudioRecord.Builder().setAudioFormat(fmt).setBufferSizeInBytes(bs).setAudioPlaybackCaptureConfig(cfg).build();
    model=new Model(new File(getFilesDir(),"vosk-"+lang).getAbsolutePath());
    recognizer=new Recognizer(model,16000f);
    record.startRecording();
    running=true;
    TranslatorOptions opt=new TranslatorOptions.Builder().setSourceLanguage(lang.equals("de")?TranslateLanguage.GERMAN:TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.POLISH).build();
    translator=Translation.getClient(opt);
    translator.downloadModelIfNeeded(new DownloadConditions.Builder().build()).addOnSuccessListener(v->{
      p.edit().putString("status","Słucham audio systemowego ("+lang.toUpperCase()+")…").apply();
      audioThread=new Thread(this::audioLoop,"SystemAudioVosk"); audioThread.start();
    }).addOnFailureListener(e->p.edit().putString("status","Błąd tłumacza: "+e.getMessage()).apply());
    ttsEngine=new TextToSpeech(this,s->{if(s==TextToSpeech.SUCCESS){ttsEngine.setLanguage(new Locale("pl","PL"));ttsEngine.setSpeechRate(1.05f);}});
   }catch(Throwable e){p.edit().putString("status","Błąd startu: "+e.getMessage()).apply();stopSelf();}
   return START_NOT_STICKY;
 }
 String text(String json,String key){try{return new JSONObject(json).optString(key,"").trim();}catch(Exception e){return "";}}
 void translate(String s){if(s.isEmpty()||translator==null)return;p.edit().putString("src",s).apply();
   translator.translate(s).addOnSuccessListener(pl->{p.edit().putString("pl",pl).putString("status","Tłumaczenie działa — audio systemowe.").apply();
     if(useTts&&ttsEngine!=null&&System.currentTimeMillis()-lastSpeak>800){lastSpeak=System.currentTimeMillis();ttsEngine.speak(pl,TextToSpeech.QUEUE_ADD,null,"live"+lastSpeak);}});
 }
 void audioLoop(){
   short[] buf=new short[4096]; String lastPartial="";
   try{
    while(running && record!=null && recognizer!=null){
      int n=record.read(buf,0,buf.length,AudioRecord.READ_BLOCKING);
      if(n<=0) continue;
      if(recognizer.acceptWaveForm(buf,n)){
        String t=text(recognizer.getResult(),"text");
        if(!t.isEmpty()) translate(t);
      }else{
        String q=text(recognizer.getPartialResult(),"partial");
        if(!q.isEmpty()&&!q.equals(lastPartial)){lastPartial=q;p.edit().putString("src",q).apply();}
      }
    }
    if(recognizer!=null){
      String t=text(recognizer.getFinalResult(),"text");
      if(!t.isEmpty()) translate(t);
    }
   }catch(Throwable e){p.edit().putString("status","Rozpoznawanie: "+e.getMessage()).apply();}
 }
 @Override public void onDestroy(){running=false;
   try{if(record!=null)record.stop();}catch(Exception ignored){}
   try{if(audioThread!=null)audioThread.interrupt();}catch(Exception ignored){}
   try{if(record!=null)record.release();}catch(Exception ignored){}
   if(translator!=null)translator.close();if(ttsEngine!=null){ttsEngine.stop();ttsEngine.shutdown();}
   if(recognizer!=null)recognizer.close();if(model!=null)model.close();if(mp!=null)mp.stop();super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}