plugins { id("com.android.application") }

android {
    namespace = "pl.livetranslator.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "pl.livetranslator.app"
        minSdk = 29
        targetSdk = 35
        versionCode = 4
        versionName = "4.0-audio-test"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
