plugins { id("com.android.application") }
android {
 namespace="pl.livetranslator.app"; compileSdk=35
 defaultConfig { applicationId="pl.livetranslator.app"; minSdk=29; targetSdk=35; versionCode=5; versionName="5.0" }
 compileOptions { sourceCompatibility=JavaVersion.VERSION_17; targetCompatibility=JavaVersion.VERSION_17 }
}
dependencies {
 implementation("androidx.appcompat:appcompat:1.7.0")
 implementation("com.google.android.material:material:1.12.0")
 implementation("com.google.mlkit:translate:17.0.3")
 implementation("com.alphacephei:vosk-android:0.3.75")
}
