package pl.livetranslator.app

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val url = findViewById<EditText>(R.id.urlInput)
        status = findViewById(R.id.statusText)
        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        findViewById<Button>(R.id.openButton).setOnClickListener {
            val value = url.text.toString().trim()
            if (value.startsWith("http")) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(value)))
            } else status.text = "Najpierw wklej link YouTube Live."
        }

        findViewById<Button>(R.id.captureButton).setOnClickListener {
            status.text = "Android poprosi o zgodę na przechwytywanie. Wybierz rozpoczęcie."
            startActivityForResult(projectionManager.createScreenCaptureIntent(), 700)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 700) {
            status.text = if (resultCode == Activity.RESULT_OK && data != null)
                "Zgoda przyznana. Moduł przechwytywania jest gotowy do podłączenia do silnika rozpoznawania mowy."
            else "Przechwytywanie anulowane."
        }
    }
}
