package pl.livetranslator.app;

import android.app.*;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import androidx.core.app.NotificationCompat;

public class PlaybackCaptureService extends Service {
    private static final String CHANNEL = "capture_test";
    private MediaProjection projection;
    private AudioRecord audioRecord;
    private Thread thread;
    private volatile boolean running;

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL, "Test audio systemowego", NotificationManager.IMPORTANCE_LOW));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = new NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Live Translator PL")
                .setContentText("Testuję dźwięk odtwarzany przez telefon")
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(17, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(17, n);
        }

        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        int resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
        Intent data;
        if (Build.VERSION.SDK_INT >= 33) {
            data = intent.getParcelableExtra("data", Intent.class);
        } else {
            data = intent.getParcelableExtra("data");
        }
        if (resultCode != Activity.RESULT_OK || data == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        try {
            MediaProjectionManager mpm =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(resultCode, data);

            AudioPlaybackCaptureConfiguration config =
                    new AudioPlaybackCaptureConfiguration.Builder(projection)
                            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                            .addMatchingUsage(AudioAttributes.USAGE_GAME)
                            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                            .build();

            int rate = 16000;
            int min = AudioRecord.getMinBufferSize(rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int buffer = Math.max(min * 2, 8192);

            AudioFormat format = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .build();

            audioRecord = new AudioRecord.Builder()
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(buffer)
                    .setAudioPlaybackCaptureConfig(config)
                    .build();

            running = true;
            getSharedPreferences("capture", MODE_PRIVATE).edit()
                    .putBoolean("active", true).putBoolean("detected", false)
                    .putInt("peak", 0).putLong("samples", 0).apply();

            audioRecord.startRecording();
            thread = new Thread(() -> loop(buffer), "PlaybackCapture");
            thread.start();
        } catch (Throwable t) {
            getSharedPreferences("capture", MODE_PRIVATE).edit()
                    .putBoolean("active", false)
                    .putString("error", t.toString()).apply();
            stopSelf();
        }

        return START_NOT_STICKY;
    }

    private void loop(int bufferBytes) {
        short[] buf = new short[Math.max(2048, bufferBytes / 2)];
        long samples = 0;
        int globalPeak = 0;

        while (running && audioRecord != null) {
            int n = audioRecord.read(buf, 0, buf.length, AudioRecord.READ_BLOCKING);
            if (n <= 0) continue;

            int peak = 0;
            long energy = 0;
            for (int i = 0; i < n; i++) {
                int v = Math.abs((int) buf[i]);
                if (v > peak) peak = v;
                energy += (long) v * v;
            }
            samples += n;
            if (peak > globalPeak) globalPeak = peak;

            double rms = Math.sqrt((double) energy / n);
            boolean detected = rms > 120 || globalPeak > 900;

            getSharedPreferences("capture", MODE_PRIVATE).edit()
                    .putBoolean("active", true)
                    .putBoolean("detected", detected ||
                            getSharedPreferences("capture", MODE_PRIVATE).getBoolean("detected", false))
                    .putInt("peak", peak)
                    .putLong("samples", samples)
                    .apply();
        }
    }

    @Override public void onDestroy() {
        running = false;
        try { if (audioRecord != null) audioRecord.stop(); } catch (Exception ignored) {}
        if (audioRecord != null) audioRecord.release();
        audioRecord = null;
        if (projection != null) projection.stop();
        projection = null;
        getSharedPreferences("capture", MODE_PRIVATE).edit().putBoolean("active", false).apply();
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
