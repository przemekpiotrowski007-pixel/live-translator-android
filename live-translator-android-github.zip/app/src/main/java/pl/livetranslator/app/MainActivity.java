package pl.livetranslator.app;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    private EditText urlInput;
    private TextView statusText, levelText;
    private MediaProjectionManager projectionManager;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final ActivityResultLauncher<String[]> permissionLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
            Boolean audio = result.get(Manifest.permission.RECORD_AUDIO);
            if (Boolean.TRUE.equals(audio)) askProjection();
            else statusText.setText("Brak zgody na RECORD_AUDIO — test nie ruszy.");
        });

    private final ActivityResultLauncher<Intent> projectionLauncher =
        registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
                statusText.setText("Nie udzielono zgody na przechwytywanie.");
                return;
            }
            Intent service = new Intent(this, PlaybackCaptureService.class);
            service.putExtra("resultCode", result.getResultCode());
            service.putExtra("data", result.getData());
            ContextCompat.startForegroundService(this, service);
            statusText.setText("Test działa. Teraz otwórz YouTube i puść live przez 10–15 sekund.");
        });

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        urlInput = findViewById(R.id.urlInput);
        statusText = findViewById(R.id.statusText);
        levelText = findViewById(R.id.levelText);
        projectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);

        findViewById(R.id.testButton).setOnClickListener(v -> beginTest());
        findViewById(R.id.youtubeButton).setOnClickListener(v -> openYoutube());
        findViewById(R.id.stopButton).setOnClickListener(v -> {
            stopService(new Intent(this, PlaybackCaptureService.class));
            getSharedPreferences("capture", MODE_PRIVATE).edit().clear().apply();
            statusText.setText("Test zatrzymany.");
            levelText.setText("Poziom audio: —");
        });

        handler.post(updateUi);
    }

    private void beginTest() {
        boolean audioGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;
        boolean notifGranted = Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        == PackageManager.PERMISSION_GRANTED;

        if (!audioGranted || !notifGranted) {
            if (Build.VERSION.SDK_INT >= 33) {
                permissionLauncher.launch(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS});
            } else {
                permissionLauncher.launch(new String[]{Manifest.permission.RECORD_AUDIO});
            }
        } else {
            askProjection();
        }
    }

    private void askProjection() {
        projectionLauncher.launch(projectionManager.createScreenCaptureIntent());
    }

    private void openYoutube() {
        String u = urlInput.getText().toString().trim();
        if (u.isEmpty()) {
            statusText.setText("Najpierw wklej link YouTube.");
            return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));
        } catch (Exception e) {
            statusText.setText("Nie udało się otworzyć YouTube.");
        }
    }

    private final Runnable updateUi = new Runnable() {
        @Override public void run() {
            var p = getSharedPreferences("capture", MODE_PRIVATE);
            boolean active = p.getBoolean("active", false);
            boolean detected = p.getBoolean("detected", false);
            int peak = p.getInt("peak", 0);
            long samples = p.getLong("samples", 0);

            if (active) {
                levelText.setText("Poziom audio: " + peak + "   próbki: " + samples);
                if (detected) statusText.setText("✅ WYKRYTO AUDIO SYSTEMOWE — YouTube można brać bez mikrofonu.");
            }
            handler.postDelayed(this, 700);
        }
    };

    @Override protected void onDestroy() {
        handler.removeCallbacks(updateUi);
        super.onDestroy();
    }
}
