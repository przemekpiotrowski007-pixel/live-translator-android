package pl.livetranslator.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements RecognitionListener {

    private static final int AUDIO_PERMISSION = 44;

    private EditText urlInput;
    private WebView youtubeView;
    private Button startButton, stopButton;
    private CheckBox ttsCheck;
    private TextView statusText, subtitleText, originalText;

    private SpeechRecognizer recognizer;
    private Intent recognizerIntent;
    private Translator translator;
    private TextToSpeech tts;
    private boolean running = false;
    private boolean modelReady = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        urlInput = findViewById(R.id.urlInput);
        youtubeView = findViewById(R.id.youtubeView);
        startButton = findViewById(R.id.startButton);
        stopButton = findViewById(R.id.stopButton);
        ttsCheck = findViewById(R.id.ttsCheck);
        statusText = findViewById(R.id.statusText);
        subtitleText = findViewById(R.id.subtitleText);
        originalText = findViewById(R.id.originalText);

        configureWebView();
        configureTranslator();
        configureTts();
        configureRecognizer();

        findViewById(R.id.loadButton).setOnClickListener(v -> loadYoutubePreview());

        startButton.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION);
            } else {
                beginTranslation();
            }
        });

        stopButton.setOnClickListener(v -> stopTranslation());
    }

    private void configureWebView() {
        WebSettings s = youtubeView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        youtubeView.setWebChromeClient(new WebChromeClient());
    }

    private void loadYoutubePreview() {
        String id = extractVideoId(urlInput.getText().toString().trim());
        if (id == null) {
            statusText.setText("Nie mogę odczytać ID filmu. Wklej normalny link YouTube.");
            return;
        }

        String html = "<!doctype html><html><body style='margin:0;background:#000'>"
                + "<iframe width='100%' height='100%' "
                + "src='https://www.youtube.com/embed/" + id + "?playsinline=1' "
                + "title='YouTube video player' frameborder='0' "
                + "allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share' "
                + "allowfullscreen></iframe></body></html>";

        youtubeView.loadDataWithBaseURL(
                "https://www.youtube.com",
                html,
                "text/html",
                "UTF-8",
                null
        );
        statusText.setText("Podgląd załadowany. Włącz film i naciśnij START TŁUMACZENIA.");
    }

    private String extractVideoId(String url) {
        Pattern[] patterns = new Pattern[] {
                Pattern.compile("youtu\\.be/([A-Za-z0-9_-]{6,})"),
                Pattern.compile("[?&]v=([A-Za-z0-9_-]{6,})"),
                Pattern.compile("youtube\\.com/live/([A-Za-z0-9_-]{6,})"),
                Pattern.compile("youtube\\.com/embed/([A-Za-z0-9_-]{6,})")
        };
        for (Pattern p : patterns) {
            Matcher m = p.matcher(url);
            if (m.find()) return m.group(1);
        }
        return null;
    }

    private void configureTranslator() {
        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.POLISH)
                .build();

        translator = Translation.getClient(options);

        DownloadConditions conditions = new DownloadConditions.Builder().build();
        translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener(v -> {
                    modelReady = true;
                    statusText.setText("Gotowe. Model EN→PL działa lokalnie na telefonie.");
                })
                .addOnFailureListener(e ->
                        statusText.setText("Nie udało się pobrać modelu tłumaczenia: " + e.getMessage()));
    }

    private void configureTts() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("pl", "PL"));
                tts.setSpeechRate(1.03f);
            }
        });
    }

    private void configureRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.setText("Ten telefon nie udostępnia systemowego rozpoznawania mowy.");
            startButton.setEnabled(false);
            return;
        }

        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(this);

        recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        );
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
    }

    private void beginTranslation() {
        if (!modelReady) {
            statusText.setText("Jeszcze pobieram model EN→PL. Spróbuj za chwilę.");
            return;
        }
        running = true;
        startButton.setEnabled(false);
        stopButton.setEnabled(true);
        statusText.setText("Słucham po angielsku… Głośnik telefonu powinien być słyszalny dla mikrofonu.");
        startListeningSafe();
    }

    private void stopTranslation() {
        running = false;
        startButton.setEnabled(true);
        stopButton.setEnabled(false);
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) {}
        }
        if (tts != null) tts.stop();
        statusText.setText("Tłumaczenie zatrzymane.");
    }

    private void startListeningSafe() {
        if (!running || recognizer == null) return;
        handler.postDelayed(() -> {
            if (!running) return;
            try {
                recognizer.startListening(recognizerIntent);
            } catch (Exception e) {
                statusText.setText("Restart rozpoznawania…");
                handler.postDelayed(this::startListeningSafe, 800);
            }
        }, 250);
    }

    private void translateFinal(String english) {
        if (english == null || english.trim().isEmpty()) return;

        originalText.setText("EN: " + english);

        translator.translate(english)
                .addOnSuccessListener(polish -> {
                    subtitleText.setText(polish);
                    statusText.setText("Tłumaczenie aktywne.");
                    if (ttsCheck.isChecked() && tts != null) {
                        tts.speak(polish, TextToSpeech.QUEUE_FLUSH, null, "live-pl");
                    }
                })
                .addOnFailureListener(e ->
                        statusText.setText("Błąd tłumaczenia: " + e.getMessage()));
    }

    @Override public void onReadyForSpeech(Bundle params) {
        statusText.setText("Słucham…");
    }

    @Override public void onBeginningOfSpeech() {}

    @Override public void onRmsChanged(float rmsdB) {}

    @Override public void onBufferReceived(byte[] buffer) {}

    @Override public void onEndOfSpeech() {
        if (running) handler.postDelayed(this::startListeningSafe, 350);
    }

    @Override public void onError(int error) {
        if (!running) return;
        statusText.setText("Nasłuch ponownie…");
        handler.postDelayed(this::startListeningSafe, error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 900 : 450);
    }

    @Override public void onResults(Bundle results) {
        ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (list != null && !list.isEmpty()) translateFinal(list.get(0));
        if (running) handler.postDelayed(this::startListeningSafe, 300);
    }

    @Override public void onPartialResults(Bundle partialResults) {
        ArrayList<String> list = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (list != null && !list.isEmpty()) {
            originalText.setText("EN: " + list.get(0));
        }
    }

    @Override public void onEvent(int eventType, Bundle params) {}

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == AUDIO_PERMISSION && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            beginTranslation();
        } else if (requestCode == AUDIO_PERMISSION) {
            statusText.setText("Bez dostępu do mikrofonu nie mogę rozpoznawać mowy.");
        }
    }

    @Override
    protected void onDestroy() {
        running = false;
        handler.removeCallbacksAndMessages(null);
        if (recognizer != null) recognizer.destroy();
        if (translator != null) translator.close();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (youtubeView != null) youtubeView.destroy();
        super.onDestroy();
    }
}
