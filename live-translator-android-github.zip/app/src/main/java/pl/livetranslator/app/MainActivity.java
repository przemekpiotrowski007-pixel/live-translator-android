package pl.livetranslator.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements RecognitionListener {
    private static final int AUDIO_PERMISSION = 44;
    private EditText urlInput;
    private Button startButton, stopButton;
    private CheckBox ttsCheck;
    private TextView statusText, subtitleText, originalText;
    private SpeechRecognizer recognizer;
    private Intent recognizerIntent;
    private Translator translator;
    private TextToSpeech tts;
    private boolean running = false, modelReady = false, restarting = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        urlInput=findViewById(R.id.urlInput);
        startButton=findViewById(R.id.startButton);
        stopButton=findViewById(R.id.stopButton);
        ttsCheck=findViewById(R.id.ttsCheck);
        statusText=findViewById(R.id.statusText);
        subtitleText=findViewById(R.id.subtitleText);
        originalText=findViewById(R.id.originalText);

        findViewById(R.id.youtubeButton).setOnClickListener(v -> openYoutube());
        startButton.setOnClickListener(v -> requestOrStart());
        stopButton.setOnClickListener(v -> stopTranslation());

        setupTranslator();
        setupTts();
        setupRecognizer();
    }

    private void openYoutube() {
        String u=urlInput.getText().toString().trim();
        if (u.isEmpty()) { statusText.setText("Najpierw wklej link do live."); return; }
        try {
            Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse(u));
            startActivity(i);
        } catch(Exception e) {
            statusText.setText("Nie udało się otworzyć linku YouTube.");
        }
    }

    private void setupTranslator() {
        TranslatorOptions o=new TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.POLISH).build();
        translator=Translation.getClient(o);
        translator.downloadModelIfNeeded(new DownloadConditions.Builder().build())
            .addOnSuccessListener(v->{ modelReady=true; statusText.setText("Gotowe. EN → PL jest przygotowane."); })
            .addOnFailureListener(e->statusText.setText("Błąd pobierania modelu EN→PL: "+e.getMessage()));
    }

    private void setupTts() {
        tts=new TextToSpeech(this, s->{
            if(s==TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("pl","PL"));
                tts.setSpeechRate(1.05f);
            }
        });
    }

    private void setupRecognizer() {
        if(!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.setText("Brak systemowego rozpoznawania mowy na tym telefonie.");
            startButton.setEnabled(false); return;
        }
        recognizer=SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(this);
        recognizerIntent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 700L);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 500L);
    }

    private void requestOrStart() {
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.RECORD_AUDIO},AUDIO_PERMISSION);
        } else begin();
    }

    private void begin() {
        if(!modelReady){ statusText.setText("Model EN→PL jeszcze się pobiera. Spróbuj za moment."); return; }
        running=true; restarting=false;
        startButton.setEnabled(false); stopButton.setEnabled(true);
        statusText.setText("Słucham angielskiego…");
        listen();
    }

    private void listen() {
        if(!running || recognizer==null || restarting) return;
        try { recognizer.startListening(recognizerIntent); }
        catch(Exception e){ restart(700); }
    }

    private void restart(long delay) {
        if(!running || restarting) return;
        restarting=true;
        handler.postDelayed(()->{
            restarting=false;
            if(running) listen();
        },delay);
    }

    private void stopTranslation() {
        running=false; restarting=false; handler.removeCallbacksAndMessages(null);
        startButton.setEnabled(true); stopButton.setEnabled(false);
        try { if(recognizer!=null) recognizer.cancel(); } catch(Exception ignored){}
        if(tts!=null) tts.stop();
        statusText.setText("Tłumaczenie zatrzymane.");
    }

    private void translate(String en) {
        if(en==null || en.trim().isEmpty()) return;
        originalText.setText("EN: "+en);
        translator.translate(en).addOnSuccessListener(pl->{
            subtitleText.setText(pl);
            statusText.setText("Tłumaczenie działa.");
            if(ttsCheck.isChecked() && tts!=null)
                tts.speak(pl,TextToSpeech.QUEUE_FLUSH,null,"pl-live");
        }).addOnFailureListener(e->statusText.setText("Błąd tłumaczenia: "+e.getMessage()));
    }

    @Override public void onReadyForSpeech(Bundle p){ statusText.setText("Słucham…"); }
    @Override public void onBeginningOfSpeech(){}
    @Override public void onRmsChanged(float r){}
    @Override public void onBufferReceived(byte[] b){}
    @Override public void onEndOfSpeech(){ restart(250); }
    @Override public void onError(int e){ if(running){ statusText.setText("Nasłuch ponownie…"); restart(e==SpeechRecognizer.ERROR_RECOGNIZER_BUSY?900:350); } }
    @Override public void onResults(Bundle b){
        ArrayList<String> x=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if(x!=null&&!x.isEmpty()) translate(x.get(0));
        restart(200);
    }
    @Override public void onPartialResults(Bundle b){
        ArrayList<String> x=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if(x!=null&&!x.isEmpty()) originalText.setText("EN: "+x.get(0));
    }
    @Override public void onEvent(int t,Bundle p){}

    @Override public void onRequestPermissionsResult(int r,@NonNull String[] p,@NonNull int[] g){
        super.onRequestPermissionsResult(r,p,g);
        if(r==AUDIO_PERMISSION && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) begin();
        else if(r==AUDIO_PERMISSION) statusText.setText("Potrzebuję zgody na mikrofon.");
    }

    @Override protected void onDestroy(){
        running=false; handler.removeCallbacksAndMessages(null);
        if(recognizer!=null) recognizer.destroy();
        if(translator!=null) translator.close();
        if(tts!=null){tts.stop();tts.shutdown();}
        super.onDestroy();
    }
}
