# Live Translator PL v5
Tryb docelowy:
- AudioPlaybackCapture / MediaProjection (bez używania mikrofonu jako źródła dźwięku)
- wybór EN albo DE
- Vosk offline STT
- Google ML Kit EN/DE -> PL
- osobno Napisy PL i Lektor PL
- modele Vosk pobierane przy pierwszym użyciu (~40–45 MB)
