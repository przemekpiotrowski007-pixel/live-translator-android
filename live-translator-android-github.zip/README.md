# Live Translator PL v3
- bez wadliwego iframe YouTube / błędu 152-4,
- otwieranie live w oficjalnym YouTube,
- ciągły nasłuch angielskiego z mikrofonu,
- lokalne tłumaczenie EN→PL przez ML Kit,
- polskie napisy i opcjonalny Android TTS.
