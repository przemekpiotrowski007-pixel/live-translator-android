# Live Translator PL — Android

Natywny szkielet aplikacji Android przygotowany pod YouTube Live, MediaProjection
i dalsze podłączenie lokalnego ASR/tłumaczenia/TTS.

GitHub Actions automatycznie buduje instalowalny debug APK po każdym pushu do `main`.
