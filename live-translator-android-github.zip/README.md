# Live Translator PL — test audio systemowego

Ta wersja nie tłumaczy jeszcze audio systemowego. Jej jedynym celem jest sprawdzić na konkretnym telefonie,
czy Android pozwala przechwycić dźwięk odtwarzany przez YouTube przez AudioPlaybackCapture + MediaProjection.

Po uruchomieniu:
1. Włącz test audio.
2. Zaakceptuj systemową zgodę.
3. Otwórz live w YouTube.
4. Odtwarzaj 10–15 sekund.
5. Wróć do aplikacji i sprawdź, czy pokazuje „WYKRYTO AUDIO SYSTEMOWE”.
