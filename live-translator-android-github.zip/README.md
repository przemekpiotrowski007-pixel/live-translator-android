# Live Translator PL v2

Wersja mobilna:
- podgląd YouTube wewnątrz aplikacji,
- rozpoznawanie angielskiej mowy z mikrofonu,
- lokalne tłumaczenie EN→PL przez Google ML Kit,
- polskie napisy,
- opcjonalny lektor Android TTS.

Pierwsze uruchomienie pobiera model tłumaczenia EN→PL.
